

<?php $__env->startSection('isi'); ?>
    <div class="mb-6 flex justify-center">
        <h2 class="text-2xl font-bold text-gray-800">Daftar Jadwal Penerbangan</h2>
    </div>

    <?php if(session('success')): ?>
        <div class="mb-6 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative shadow-sm" role="alert">
            <strong class="font-bold">Berhasil!</strong>
            <span class="block sm:inline"><?php echo e(session('success')); ?></span>
        </div>
    <?php endif; ?>

    
    <!-- justify center buat ke terngah2     flex wrap supaya kartu turun   gap jarak antar kartu -->
    <div class="flex flex-row justify-center flex-wrap gap-6">  
        <?php $__currentLoopData = $flights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="relative flex flex-col bg-red-50 rounded-sm ">
                <a class="px-4 py-3 "><?php echo e($flight->flight_code); ?></a>
                
                <div class="flex flex-row items-center">
                    <div class="flex flex-col">
                        <a class="px-4 py-3 text-center "><?php echo e($flight->origin); ?></a>
                    </div>
                    <div class="flex flex-col justify-between">
                        <a > ➔ </a>
                    </div>
                    <div class="flex flex-col">
                        <a class="px-4 py-3 text-center "><?php echo e($flight->destination); ?></a>
                    </div>                
                </div>
                

                <a class="px-4 py-3 "><?php echo e($flight->departure_time); ?></a>
                <a class="px-4 py-3 "><?php echo e($flight->arrival_time); ?></a>
                
                <div class="flex flex-row justify-between items-center px-4 py-4 gap-3">
                    
                    <a href="/flights/book/<?php echo e($flight->id); ?>" class="w-1/2 text-center bg-green-500 hover:bg-green-600 text-white text-sm font-bold py-2 px-3 rounded shadow transition duration-200">
                        Pesan Tiket
                    </a>
                    
                    <a href="/flights/ticket/<?php echo e($flight->id); ?>" class="w-1/2 text-center bg-blue-500 hover:bg-blue-600 text-white text-sm font-bold py-2 px-3 rounded shadow transition duration-200">
                        View
                    </a>
                    
                </div>
            </div> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.Base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Bryan\BelajarWFD_UTS\uts24\resources\views/Layouts/flightDashboard.blade.php ENDPATH**/ ?>