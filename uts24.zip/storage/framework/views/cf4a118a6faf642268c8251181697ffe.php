

<?php $__env->startSection('isi'); ?>
<div class="max-w-6xl mx-auto px-4">

    <?php if(session('success')): ?>
        <div class="mb-6 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative shadow-sm">
            <strong class="font-bold">Berhasil!</strong>
            <span class="block sm:inline"><?php echo e(session('success')); ?></span>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="mb-6 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative shadow-sm">
            <strong class="font-bold">Gagal!</strong>
            <span class="block sm:inline"><?php echo e(session('error')); ?></span>
        </div>
    <?php endif; ?>

    <div class="bg-white rounded-lg shadow-md p-6 mb-8 border-l-8 border-indigo-600">
        <div class="flex justify-between items-start">
            <div>
                <h2 class="text-3xl font-bold text-gray-800">Ticket Details for <?php echo e($flight->flight_code); ?></h2>
                <p class="text-xl text-indigo-600 font-semibold"><?php echo e($flight->origin); ?> ➔ <?php echo e($flight->destination); ?></p>
            </div>
            <div class="text-right text-sm text-gray-500">
                <p>Departure: <span class="text-gray-800 font-medium"><?php echo e($flight->departure_time); ?></span></p>
                <p>Arrived: <span class="text-gray-800 font-medium"><?php echo e($flight->arrival_time); ?></span></p>
            </div>
        </div>
        
        <div class="mt-4 pt-4 border-t flex gap-4 text-sm text-gray-600">
            <span><strong><?php echo e($tickets->count()); ?></strong> passengers</span>
            <span>•</span>
            <span><strong><?php echo e($tickets->where('is_boarding', 1)->count()); ?></strong> boardings</span>
        </div>
    </div>

    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="bg-gray-100 px-6 py-4 border-b">
            <h3 class="font-bold text-gray-700">Passengers List</h3>
        </div>
        <table class="w-full text-left border-collapse">
            <thead>
                <tr class="bg-gray-50 text-gray-600 text-sm uppercase">
                    <th class="px-6 py-3 border-b">No.</th>
                    <th class="px-6 py-3 border-b">Passenger Name</th>
                    <th class="px-6 py-3 border-b">Phone</th>
                    <th class="px-6 py-3 border-b">Seat</th>
                    <th class="px-6 py-3 border-b text-center">Boarding Status</th>
                    <th class="px-6 py-3 border-b text-center">Action</th>
                </tr>
            </thead>
            <tbody class="text-gray-700">
                <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4 border-b"><?php echo e($index + 1); ?></td>
                    <td class="px-6 py-4 border-b font-medium"><?php echo e($ticket->passanger_name); ?></td>
                    <td class="px-6 py-4 border-b"><?php echo e($ticket->passenger_phone); ?></td>
                    <td class="px-6 py-4 border-b font-mono text-indigo-600"><?php echo e($ticket->seat_number); ?></td>
                    
                    <td class="px-6 py-4 border-b text-center">
                        <?php if($ticket->is_boarding): ?>
                            <span class="text-green-600 font-semibold text-sm">
                                ✓ <?php echo e($ticket->boarding_time); ?>

                            </span>
                        <?php else: ?>
                            <form action="/ticket/board/<?php echo e($ticket->id); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?> <button type="submit" class="bg-indigo-500 hover:bg-indigo-600 text-white text-xs px-3 py-1 rounded shadow">
                                    Confirm
                                </button>
                            </form>
                        <?php endif; ?>
                    </td>

                    <td class="px-6 py-4 border-b text-center">
                        <?php if(!$ticket->is_boarding): ?>
                            <form action="/ticket/delete/<?php echo e($ticket->id); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus tiket ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-500 hover:text-red-700 text-sm font-bold">
                                    Delete
                                </button>
                            </form>
                        <?php else: ?>
                            <span class="text-gray-400 text-xs italic">Locked</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($tickets->isEmpty()): ?>
                <tr>
                    <td colspan="6" class="px-6 py-10 text-center text-gray-500 italic">Belum ada penumpang untuk penerbangan ini.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-6">
        <a href="/flight" class="text-indigo-600 hover:underline font-semibold">← Back to Dashboard</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.Base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Bryan\BelajarWFD_UTS\uts24\resources\views/Layouts/ticketDashboard.blade.php ENDPATH**/ ?>