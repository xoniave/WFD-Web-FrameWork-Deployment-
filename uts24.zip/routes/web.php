<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FlightController;
use App\Http\Controllers\TicketController;

Route::get('/flight', [FlightController::class, 'AmbilFlight']);
Route::redirect('/', '/flight');

Route::get('/flights/book/{id}', [TicketController::class, 'book']);
Route::get('/flights/ticket/{id}', [TicketController::class, 'AmbilTicket']);

Route::post('/ticket/submit', [TicketController::class, 'submit']);

Route::put('/ticket/board/{id}', [TicketController::class, 'board']);
Route::delete('/ticket/delete/{id}', [TicketController::class, 'delete']);