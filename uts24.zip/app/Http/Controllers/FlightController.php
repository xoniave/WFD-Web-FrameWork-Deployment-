<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Flight;

class FlightController extends Controller
{
    public function AmbilFlight()
    {
        // 1. Ambil semua data penerbangan dari database
        $flights = Flight::all();

        // 2. Kirim datanya ke file tampilan bernama 'flight.blade.php'
        return view('Layouts.flightDashboard', compact('flights'));
    }
}
