<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Flight; 
use App\Models\Ticket;

class TicketController extends Controller
{
    //
    public function book($id)
    {
        // Cari pesawat berdasarkan ID yang diklik
        $flight = Flight::findOrFail($id);
        
        // Buka file tampilan 'book.blade.php' dan bawa data pesawatnya
        return view('Layouts.Book', compact('flight'));
    }

    public function AmbilTicket($id){
        $flight = Flight::findOrFail($id);
        $tickets = Ticket::where('flight_id', $id)->get();

        return view('Layouts.ticketDashboard', compact('flight', 'tickets'));
    }

    public function board($id)
    {
        // 1. Cari tiketnya
        $ticket = Ticket::findOrFail($id);

        // 2. Ubah status boarding dan catat waktu saat ini (sesuai soal UTS)
        $ticket->is_boarding = 1; 
        $ticket->boarding_time = now(); // Fungsi bawaan Laravel untuk mengambil waktu saat ini
        $ticket->save();

        // 3. Kembalikan ke halaman sebelumnya dengan pesan sukses
        return redirect()->back()->with('success', 'Boarding atas nama ' . $ticket->passanger_name . ' berhasil dikonfirmasi!');
    }

    public function delete($id)
    {
        // 1. Cari tiketnya
        $ticket = Ticket::findOrFail($id);

        // 2. Validasi sesuai soal UTS: Tiket yang sudah boarding TIDAK BOLEH dihapus
        if ($ticket->is_boarding == 1) {
            // Lempar kembali dengan pesan error
            return redirect()->back()->with('error', 'Tiket atas nama ' . $ticket->passanger_name . ' gagal dihapus karena sudah melakukan boarding!');
        }

        // 3. Jika belum boarding, hapus tiketnya
        $ticket->delete();

        // 4. Kembalikan ke halaman sebelumnya dengan pesan sukses
        return redirect()->back()->with('success', 'Tiket atas nama ' . $ticket->passanger_name . ' berhasil dihapus!');
    }

    // Fungsi untuk memproses data dari form pemesanan
    public function submit(Request $request)
    {
        // 1. Validasi Data (Sesuai poin 8a di soal UTS)
        $request->validate([
            'flight_id' => 'required',
            'passanger_name' => 'required|string',
            'passenger_phone' => 'required|string|max:14',
            'seat_number' => 'required|string|max:3',
        ]);

        // 2. Simpan ke Database Tabel Tickets
        Ticket::create([
            'flight_id' => $request->flight_id,
            'passanger_name' => $request->passanger_name,
            'passenger_phone' => $request->passenger_phone,
            'seat_number' => $request->seat_number,
            'is_boarding' => false, // Defaultnya belum boarding (0)
        ]);

        // 3. Kembalikan user ke halaman jadwal penerbangan dengan membawa pesan sukses (Poin 8b UTS)
        return redirect('/flight')->with('success', 'Tiket atas nama ' . $request->passanger_name . ' berhasil dipesan!');
    }

}
