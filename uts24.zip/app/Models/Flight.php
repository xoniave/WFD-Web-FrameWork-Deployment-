<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Flight extends Model
{
    //
    use HasFactory;

    protected $fillable = [
        'flight_code',
        'origin',
        'destination',
        'departure_time',
        'arrival_time',
    ];


    // Relasi One-to-Many: 1 Flight memiliki banyak Ticket jadi bisa ada byk ticket makanya fungsi pake s
    public function tickets()
    {
        return $this->hasMany(Ticket::class);
    }
}
