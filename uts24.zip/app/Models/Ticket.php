<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Ticket extends Model
{
    //
    use HasFactory;

    // Menentukan kolom apa saja yang boleh diisi (fillable)
    protected $fillable = [
        'flight_id',
        'passanger_name',
        'passenger_phone',
        'seat_number',
        'is_boarding',
        'boarding_time',
    ];

    // Relasi Many-to-One: 1 Ticket dimiliki oleh 1 Flight  makanya flight gk pake s
    public function flight()
    {
        return $this->belongsTo(Flight::class);
    }
}
