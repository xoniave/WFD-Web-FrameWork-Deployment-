@extends('Layouts.Base')

@section('isi')
    <div class="max-w-3xl mx-auto bg-gray-50 p-8 rounded-lg shadow-md border border-gray-200">
        
        <h2 class="text-2xl font-bold text-gray-800 mb-6 border-b pb-4">Ticket Booking for <span class="float-right text-indigo-700">{{ $flight->flight_code }}</span></h2>
        
        <div class="flex justify-between items-center bg-gray-200 p-4 rounded mb-8 font-semibold text-gray-700">
            <div>{{ $flight->origin }} ➔ {{ $flight->destination }}</div>
            <div class="text-sm">Departure: <span class="font-normal">{{ $flight->departure_time }}</span></div>
            <div class="text-sm">Arrived: <span class="font-normal">{{ $flight->arrival_time }}</span></div>
        </div>

        <form action="/ticket/submit" method="POST">
            <!-- tiket butuh simpen data ID pesawat -->
            @csrf <input type="hidden" name="flight_id" value="{{ $flight->id }}">

            <div class="mb-5 flex items-center">
                <label class="w-1/3 text-gray-700 font-semibold">Passenger Name</label>
                <input type="text" name="passanger_name" required class="w-2/3 p-2 border border-gray-300 rounded bg-gray-100 focus:bg-white focus:outline-indigo-500">
            </div>

            <div class="mb-5 flex items-center">
                <label class="w-1/3 text-gray-700 font-semibold">Passenger Phone</label>
                <input type="text" name="passenger_phone" required class="w-2/3 p-2 border border-gray-300 rounded bg-gray-100 focus:bg-white focus:outline-indigo-500">
            </div>

            <div class="mb-8 flex items-center">
                <label class="w-1/3 text-gray-700 font-semibold">Seat Number</label>
                <input type="text" name="seat_number" required class="w-1/3 p-2 border border-gray-300 rounded bg-gray-100 focus:bg-white focus:outline-indigo-500" placeholder="e.g. A01">
            </div>

            <div class="flex justify-end gap-4 mt-6 border-t pt-6">
                <a href="/flight" class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold py-2 px-6 rounded shadow">Cancel</a>
                <button type="submit" class="bg-gray-400 hover:bg-gray-500 text-white font-bold py-2 px-6 rounded shadow transition">Book Ticket</button>
            </div>
        </form>
    </div>
@endsection