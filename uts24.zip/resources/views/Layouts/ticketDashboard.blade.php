@extends('Layouts.Base')

@section('isi')
<div class="max-w-6xl mx-auto px-4">

    @if (session('success'))
        <div class="mb-6 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative shadow-sm">
            <strong class="font-bold">Berhasil!</strong>
            <span class="block sm:inline">{{ session('success') }}</span>
        </div>
    @endif

    @if (session('error'))
        <div class="mb-6 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative shadow-sm">
            <strong class="font-bold">Gagal!</strong>
            <span class="block sm:inline">{{ session('error') }}</span>
        </div>
    @endif

    <div class="bg-white rounded-lg shadow-md p-6 mb-8 border-l-8 border-indigo-600">
        <div class="flex justify-between items-start">
            <div>
                <h2 class="text-3xl font-bold text-gray-800">Ticket Details for {{ $flight->flight_code }}</h2>
                <p class="text-xl text-indigo-600 font-semibold">{{ $flight->origin }} ➔ {{ $flight->destination }}</p>
            </div>
            <div class="text-right text-sm text-gray-500">
                <p>Departure: <span class="text-gray-800 font-medium">{{ $flight->departure_time }}</span></p>
                <p>Arrived: <span class="text-gray-800 font-medium">{{ $flight->arrival_time }}</span></p>
            </div>
        </div>
        
        <div class="mt-4 pt-4 border-t flex gap-4 text-sm text-gray-600">
            <span><strong>{{ $tickets->count() }}</strong> passengers</span>
            <span>•</span>
            <span><strong>{{ $tickets->where('is_boarding', 1)->count() }}</strong> boardings</span>
        </div>
    </div>

    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="bg-gray-100 px-6 py-4 border-b">
            <h3 class="font-bold text-gray-700">Passengers List</h3>
        </div>
        <table class="w-full text-left border-collapse">
            <thead>
                <tr class="bg-gray-50 text-gray-600 text-sm uppercase">
                    <th class="px-6 py-3 border-b">No.</th>
                    <th class="px-6 py-3 border-b">Passenger Name</th>
                    <th class="px-6 py-3 border-b">Phone</th>
                    <th class="px-6 py-3 border-b">Seat</th>
                    <th class="px-6 py-3 border-b text-center">Boarding Status</th>
                    <th class="px-6 py-3 border-b text-center">Action</th>
                </tr>
            </thead>
            <tbody class="text-gray-700">
                @foreach($tickets as $index => $ticket)
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4 border-b">{{ $index + 1 }}</td>
                    <td class="px-6 py-4 border-b font-medium">{{ $ticket->passanger_name }}</td>
                    <td class="px-6 py-4 border-b">{{ $ticket->passenger_phone }}</td>
                    <td class="px-6 py-4 border-b font-mono text-indigo-600">{{ $ticket->seat_number }}</td>
                    
                    <td class="px-6 py-4 border-b text-center">
                        @if($ticket->is_boarding)
                            <span class="text-green-600 font-semibold text-sm">
                                ✓ {{ $ticket->boarding_time }}
                            </span>
                        @else
                            <form action="/ticket/board/{{ $ticket->id }}" method="POST">
                                @csrf
                                @method('PUT') <button type="submit" class="bg-indigo-500 hover:bg-indigo-600 text-white text-xs px-3 py-1 rounded shadow">
                                    Confirm
                                </button>
                            </form>
                        @endif
                    </td>

                    <td class="px-6 py-4 border-b text-center">
                        @if(!$ticket->is_boarding)
                            <form action="/ticket/delete/{{ $ticket->id }}" method="POST" onsubmit="return confirm('Yakin ingin menghapus tiket ini?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-red-500 hover:text-red-700 text-sm font-bold">
                                    Delete
                                </button>
                            </form>
                        @else
                            <span class="text-gray-400 text-xs italic">Locked</span>
                        @endif
                    </td>
                </tr>
                @endforeach

                @if($tickets->isEmpty())
                <tr>
                    <td colspan="6" class="px-6 py-10 text-center text-gray-500 italic">Belum ada penumpang untuk penerbangan ini.</td>
                </tr>
                @endif
            </tbody>
        </table>
    </div>

    <div class="mt-6">
        <a href="/flight" class="text-indigo-600 hover:underline font-semibold">← Back to Dashboard</a>
    </div>
</div>
@endsection