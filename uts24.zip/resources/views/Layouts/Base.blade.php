<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Base</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>


<body>
    <Header class=" relative flex bg-gray-800/50">
    <div class="mx-auto  px-7">
        <div class="relative flex h-16 items-center">
                <h5 class="font-semibold text-gray-800 ">SISTEM AIRPLANE</h5>
        </div>
    </div>
    </Header>


    <main class="flex-grow">
            @yield('isi')
    </main>


    <footer class="mt-12 py-4 border-t border-gray-300 text-center text-sm font-semibold text-gray-800 italic">
        by bryan - 2024
    </footer>

</body>


</html>