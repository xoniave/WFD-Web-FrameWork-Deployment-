<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('flights', function (Blueprint $table) {
            $table->id(); // auto increment (primary key) [cite: 23]
            $table->string('flight_code', 5)->unique(); // required, unique, string(5) [cite: 24]
            $table->string('origin', 3); // required, string(3) [cite: 25]
            $table->string('destination', 3); // required, string(3) [cite: 26]
            $table->dateTime('departure_time'); // required, datetime [cite: 27]
            $table->dateTime('arrival_time'); // required, datetime [cite: 28]
            $table->timestamps(); // otomatis membuat created_at dan updated_at [cite: 29, 30]
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('flights');
    }
};
