<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tickets', function (Blueprint $table) {
            $table->id(); // auto increment (primary key)
            
            // foreign key ke tabel flights [cite: 36]
            $table->foreignId('flight_id')->constrained('flights')->cascadeOnDelete(); 
            
            $table->string('passanger_name'); // required, string (mengikuti ejaan soal UTS) [cite: 37]
            $table->string('passenger_phone', 14); // required, string(14) [cite: 38]
            $table->string('seat_number', 3); // required, string(3) [cite: 39]
            $table->boolean('is_boarding')->default(false); // required, default FALSE (0) [cite: 40]
            $table->dateTime('boarding_time')->nullable(); // datetime, nullable [cite: 41]
            
            $table->timestamps(); // otomatis membuat created_at dan updated_at [cite: 42, 43]
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tickets');
    }
};
